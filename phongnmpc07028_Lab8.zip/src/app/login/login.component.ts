import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  constructor(private authService: AuthService, private router: Router) { }

  // login() {
  //   this.authService.login();
  //   this.router.navigate(['/admin-dashboard']);
  // }

  // logout() {
  //   this.authService.logout();
  //   this.router.navigate(['/home']);
  // }
}
