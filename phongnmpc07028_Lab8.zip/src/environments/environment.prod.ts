export const environment = {
  production: true,
  url : 'http://localhost:3000/api/posts'
};
